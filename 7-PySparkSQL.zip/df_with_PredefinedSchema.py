# import pyspark

from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("Python Spark SQL Read Write example").getOrCreate()

spark.read.csv("/FileStore/tables/countries.csv")

countries_df = spark.read.csv("/FileStore/tables/countries.csv")
type(countries_df)
countries_df.show(5)
countries_df.printSchema()

countries_df = spark.read.csv("/FileStore/tables/countries.csv", header=True)
countries_df.show(5)
countries_df.printSchema()

countries_df = spark.read.options(header=True).csv('/FileStore/tables/countries.csv')
countries_df.printSchema()
countries_df.show(5)
countries_df.dtypes
countries_df.printSchema()
countries_df.describe().show(5)

countries_df = spark.read.options(header=True, inferSchema=True).csv('countries.csv')
countries_df.printSchema()
countries_df.show(5)

countries_df = spark.read.options(header=True).options(inferSchema=True).csv('countries.csv')
countries_df.printSchema()
countries_df.show(5)

countries_df = spark.read.format('csv').options(header=True).options(inferSchema=True).load('countries.csv')
countries_df.printSchema()
countries_df.show(5)

countries_df = spark.read.csv("/FileStore/tables/countries.csv", header=True, inferSchema=True)
countries_df.printSchema()
countries_df.show(5)

# Importing Types
from pyspark.sql.types import IntegerType, StringType, DoubleType, StructField, StructType
countries_schema = StructType([
                    StructField("COUNTRY_ID", IntegerType(), False),
                    StructField("NAME", StringType(), False),
                    StructField("NATIONALITY", StringType(), False),
                    StructField("COUNTRY_CODE", StringType(), False),
                    StructField("ISO_ALPHA2", StringType(), False),
                    StructField("CAPITAL", StringType(), False),
                    StructField("POPULATION", DoubleType(), False),
                    StructField("AREA_KM2", IntegerType(), False),
                    StructField("REGION_ID", IntegerType(), True),
                    StructField("SUB_REGION_ID", IntegerType(), True),
                    StructField("INTERMEDIATE_REGION_ID", IntegerType(), True),
                    StructField("ORGANIZATION_REGION_ID", IntegerType(), True)
                    ]
                    )

# Reading in the csv file and passing in the schema defined in the previous cell. Note the data types
countries_df = spark.read.csv('countries.csv', header=True, schema=countries_schema)

countries_df.printSchema()
countries_df.show(5)
